Files in the archive:
- project1.hs (source code)

To compile my project and run it, just simply type 'ghc project1.hs' to compile and 'runhaskell project1.hs' to run it

